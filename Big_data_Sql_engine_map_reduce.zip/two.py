#!/usr/bin/python3
import subprocess
import re
import os
import sys
def run_cmd(args_list):
        #print('Running system command: {0}'.format(' '.join(args_list)))
        proc = subprocess.Popen(args_list, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        s_output, s_err = proc.communicate()
        s_return =  proc.returncode
        return s_return, s_output, s_err 
x=""
data=[]
f=open("/home/hduser/query.txt","r")
x=f.read()
f.close()
query=x.strip("()")
query_array=re.split(" ",query)
type_query=query_array[0]
if((type_query.upper())=="LOAD"):#load /bigdata/table/table.csv as (a,b,c,d)
	data_path=query_array[1]
	os.system("hdfs dfs -mkdir /bigdata")
	table=re.split("/",data_path)[-1]
	os.system("hdfs dfs -mkdir /bigdata/"+table)
	os.system("hdfs dfs -mkdir /schemas")
	print(query_array)
	schema=query_array[3].strip("()")
	table=re.split("/",data_path)[-1]
	file=open("/home/hduser/schema_"+table.split("/")[-1]+".txt","w")
	file.write(schema)
	file.close()
	schema_path="/home/hduser/schema_"+table+".txt"
	os.system("hdfs dfs -put "+data_path+" /bigdata/"+table)
	os.system("hdfs dfs -put "+schema_path+" /schemas/")
	exit(0)
elif((type_query.upper())=="SELECT"):
	for line in sys.stdin:
		data.append(line)
	colnam=query_array[1]
	table=query_array[3]
	(ret, out1, err)=run_cmd(['hdfs', 'dfs', '-cat', '/schemas/schema_'+table.split("/")[-1].strip()+'.csv.txt'])
	schm=out1.decode()
	schema_array=re.split(",",schm)
	schema_array[0]=schema_array[0].split("\n")[1]
	out=data
	if(colnam=="*"):
		lines=out
		if(len(query_array)>4):
			symbol=query_array[6]
			for i in range(len(lines)):
				if(symbol==">"):
					colname=query_array[5]
					try:
						col=schema_array.index(colname)
						where=int(query_array[7])
						if(int(re.split(',',lines[i])[col])>where):
							print(lines[i])
					except:
						print("COLUMN NOT PRESENT IN SCHEMA")
				elif(symbol=="<"):
					colname=query_array[5]
					try:
						col=schema_array.index(colname)
						where=int(query_array[7])
						if(int(re.split(',',lines[i])[col])>where):
							print(lines[i])
					except:
						print("COLUMN NOT PRESENT IN SCHEMA")
				elif(symbol=="="):	
					dat=[]
					colname=query_array[5]
					try:
						col=schema_array.index(colname)
						where=str(query_array[7])
						if(str(re.split(',',lines[i])[col])==where):					
							print(lines[i])
					except:
						print("COLUMN NOT PRESENT IN SCHEMA")
		else:
			for i in range(len(lines)):
				print("%s"%(lines[i]))
	else:
		if(len(query_array)>4):#where exists in the column
			try:
				col=schema_array.index(colnam)#slect age from table order by count
				where=query_array[4]#select 
				if((where.upper())=="WHERE"):
					#print("inside where")
					symbol=query_array[6]
					lines=out
					for i in range(len(lines)):
						if(symbol==">"):
							where=int(query_array[7])
							if(int(re.split(',',lines[i])[col])>where):
								print(re.split(',',lines[i])[col])
						elif(symbol=="<"):
							where=int(query_array[7])
							if(int(re.split(',',lines[i])[col])<where):
								print(re.split(',',lines[i])[col])
						elif(symbol=="="):
							where=str(query_array[7])
							if(str(re.split(',',lines[i])[col])==where):
								print(re.split(',',lines[i])[col])
		
				else:
					col=schema_array.index(colnam)
					lines=out
					for i in range(len(lines)):
						ans=re.split(",",lines[i])
						print("%s"%(ans[col]))
			except:
				print("COLUMN NAME NOT PRESENT OR DATATYPE INVALID IN SCHEMA")
		else:
			try:
				col=schema_array.index(colnam)
				lines=out
				for i in range(len(lines)):
					ans=re.split(",",lines[i])
					print(ans[col])
			except:
				print("COLUMN NOT PRESENT IN SCHEMA")
elif((type_query.upper())=="DELETE"):
	if(len(query_array)!=4):
		print("skl")
		pass#delete table from database
	else:
		tablename=query_array[1].split("/")[-1]
		databasename=query_array[3]
		os.system('hdfs dfs -rmr /'+databasename+'/'+tablename+".csv")
		os.system('hdfs dfs -rm /schemas/schema_'+tablename+'.csv.txt')
		print("DELETED "+tablename)
