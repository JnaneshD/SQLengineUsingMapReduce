import subprocess
import re
import os
import sys
def run_cmd(args_list):
        #print('Running system command: {0}'.format(' '.join(args_list)))
        proc = subprocess.Popen(args_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        s_output, s_err = proc.communicate()
        s_return =  proc.returncode
        return s_return, s_output, s_err
def run(tablename):
	(ret, out1, err)=run_cmd(['hdfs', 'dfs', '-test', '-e','/bigdata/'+tablename.split("/")[-1]+".csv"])
	print("bigdata/"+tablename.split("/")[-1]+".csv")
	if(ret==0):
		os.system("hadoop jar /usr/local/hadoop/share/hadoop/tools/lib/hadoop-streaming-2.7.2.jar -file two.py -mapper two.py -file reducer1.py -reducer reducer1.py -input /bigdata/"+tablename.split("/")[-1]+".csv"+" -output /input/output")
		os.system("hdfs dfs -cat /input/output/part-00000")
		os.system("hdfs dfs -rmr /input/output")
	else:
		print("NO SUCH TABLE IN DATABASE")
def run_order(tablename):
	print("bigdata/"+tablename.split("/")[-1]+".csv")
	print(tablename)
	rt=os.system("hdfs dfs -test -e /bigdata/"+tablename)
	(ret, out1, err)=run_cmd(['hdfs', 'dfs', '-test', '-e','/bigdata/'+tablename.split("/")[-1]+".csv"])
	if(ret==0):
		os.system("hadoop jar /usr/local/hadoop/share/hadoop/tools/lib/hadoop-streaming-2.7.2.jar -file two.py -mapper two.py -file reducer2.py -reducer reducer2.py -input /bigdata/"+tablename.split("/")[-1]+".csv -output /input/output")
		os.system("hdfs dfs -cat /input/output/part-00000")
		os.system("hdfs dfs -rmr /input/output")
	else:
		print("NO SUCH TABLE IN DATABASE")
query=str(input("$ENTRY THE QUERY  :"))
f=open("/home/hduser/query.txt","w")
f.write(query)#slec min (column) form table
f.close()#selcet * from kjn aggregate by count
query_array=re.split(" ",query)
orderby=""
table_name=query_array[3]

aggr=query_array[1]
if(len(query_array)>4):
	orderby=query_array[4]
if((orderby.lower())=="aggregate"):
	if(len(query_array)!=7):
		print(query_array)
		f=open("/home/hduser/query.txt","w")
		f.write(query_array[0]+" "+query_array[1]+" "+query_array[2]+" "+query_array[3])
		f.close()
		aggregate=query_array[4]
		count=query_array[6]
		asds=query_array[7]
		fil=open("/home/hduser/aggregate.txt","w")
		fil.write(count+" "+aggregate+" "+asds)
		fil.close()
		run_order(table_name)
		exit(-1)
	else:
		print("PLEASE USE FORMAT : SELECT COLUMN FROM TABLE ORDER BY COUNT ASC/DESC")
if((aggr.lower())=="max" or (aggr.lower())=="min" or (aggr.lower())=="count"):
	if((aggr.lower())=="count"):
		column=query_array[2].strip("()")
		f=open("/home/hduser/query.txt","w")
		f.write(query_array[0]+" * "+query_array[3]+" "+query_array[4])
		#f.write(query_array[0]+" "+column+" "+query_array[3]+" "+query_array[4])
		table_name=query_array[4]
		f.close()
		f=open("/home/hduser/aggregate.txt","w")
		f.write(aggr)
		f.close()
		run(table_name)
		exit(0)
	else:	
		f=open("/home/hduser/query.txt","w")
		column=query_array[2].strip("()")
		f.write(query_array[0]+" "+column+" "+query_array[3]+" "+query_array[4])
		f.close()
		f=open("/home/hduser/aggregate.txt","w")
		f.write(aggr)
		f.close()
		table_name=query_array[4]
		run(table_name)
		exit(0)
elif(len(query_array)==4):
	fil=open("/home/hduser/aggregate.txt","w")
	fil.write("")
	fil.close()
	if((query_array[0].upper())=="LOAD" or (query_array[0].upper())=="DELETE"):
		os.system("python3 two.py")
	else:
		run(table_name)
elif(len(query_array)>5):	
	if(len(query_array)==8):#select age from table where age > 9
		fil=open("/home/hduser/aggregate.txt","w")
		fil.write("")
		fil.close()
		run(table_name)
		exit(0)
